﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;
using XUnlocker;

namespace XUnlocker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Text = "Task Manager";
            button2.Text = "Registry Editor";
            button3.Text = "About";
            button4.Text = "XBrowser";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start("taskmgr.exe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("regedit.exe");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            XUnlocker.Form2 form2 = new Form2();
            form2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("XUnlocker by Luxidev\nVersion 1.0\n© Copyright 2025", "XUnlocker 1.0");
        }
    }
}
